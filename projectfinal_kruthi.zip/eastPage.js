let selectedCity = "";
function getQuote() {
    selectedCity = document.getElementById("placeDropDown").value;
    if (selectedCity == "Kolkata") {
        // document.getElementById("selectedCity") ? document.getElementById("selectedCity").innerHTML = "" + selectedCity + " will cost around 3000-5000INR" : "" +"<br>";
        document.getElementById("selectedCity").innerHTML = "" + selectedCity + " is most populous metropolitan city and is a pioneer in field of arts and literature." + "<br>" + " Place visit will cost around 3000-5000INR" + "<br>"
    }
    if (selectedCity == "Darjeeling") {
        document.getElementById("selectedCity").innerHTML = "" + selectedCity + "is a famous hill station offering a breath taking sight of the numerous peaks of the majestic himalayas." + "<br>" + "Place visit will cost around 5000INR approximately" + "<br>"
    }
    if (selectedCity == "Gangtok") {
        document.getElementById("selectedCity").innerHTML = "" + selectedCity + " is a place which overlooks the spectacular Kanchenjunga and serves to be the base for exploring the rest of the state." + "<br>" + "Place visit will cost above 5000INR"
    }
    if (selectedCity == "Mizoram"){
        document.getElementById("selectedCity").innerHTML =""+ selectedCity +" is a place which is an idyllic land of great beauty having rich variety of flora and fauna"+"<br>"+"Place visit will cost in the range of 5000-10000INR"
    }
    if(selectedCity == "Shillong"){
        document.getElementById("selectedCity").innerHTML =""+selectedCity+" is a place which means abode of clouds which is a beautiful hill station in the North-Eastern part of India."+"<br>"+"Place visit will cost in the range of 4000-8000INR"
    }
    if(selectedCity == "Tawang"){
        document.getElementById("selectedCity").innerHTML =""+selectedCity+ "is famous for its 400 year old monastery and is famous for its natural beauty which attracts and enchants travellers"+"</br>"+"Place visit will cost around 7000INR"
    }
}

